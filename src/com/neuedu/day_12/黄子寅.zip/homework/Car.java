package com.neuedu.day_12.homework;

public class Car {
    private String carNumber;
    private String brond;
    private String color;
    private double kil;

    public Car(String carNumber, String brond, String color, double kil) {
        this.carNumber = carNumber;
        this.brond = brond;
        this.color = color;
        this.kil = kil;
    }
}

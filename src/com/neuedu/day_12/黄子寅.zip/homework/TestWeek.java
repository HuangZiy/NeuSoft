package com.neuedu.day_12.homework;

public class TestWeek {
    public static void main(String[] args) {
        Week week = new Week(7);
        week.show();
    }

}

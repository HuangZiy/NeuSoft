package com.neuedu.day_12.homework;

public class TestFF {
    public static void main(String[] args) {
        FilpFlop ff = new FilpFlop(15);
        ff.show();
        FilpFlop ff1 = new FilpFlop(10);
        ff1.show();
        FilpFlop ff2 = new FilpFlop(9);
        ff2.show();
        FilpFlop ff3 = new FilpFlop(8);
        ff3.show();
    }
}

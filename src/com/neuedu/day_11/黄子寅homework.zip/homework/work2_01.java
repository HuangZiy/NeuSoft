package com.neuedu.day_11.homework;

public class work2_01 {
    public static void main(String[] args){

        String str = "null";

        if (str == null) {

            System.out.println("null");

        }else if (str.length() == 0) {

            System.out.println("zero");

        }else{

            System.out.println("some");

        }

    }
}
//答案some,"null"是一个字符串
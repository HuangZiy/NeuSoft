package com.neuedu.day_11.homework;

public class work2_03 {
    public static void main(String[] args) {
        String s="today";
        System.out.println(s.substring(2,5));
        System.out.println(s.substring(2));
        System.out.println(s.substring(3));
        System.out.println(s.substring(3,5));
    }
}
